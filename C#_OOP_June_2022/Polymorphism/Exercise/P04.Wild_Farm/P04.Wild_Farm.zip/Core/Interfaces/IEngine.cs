﻿namespace P04.Wild_Farm.Core.Interfaces
{
    public interface IEngine
    {
        void Start();
    }
}
