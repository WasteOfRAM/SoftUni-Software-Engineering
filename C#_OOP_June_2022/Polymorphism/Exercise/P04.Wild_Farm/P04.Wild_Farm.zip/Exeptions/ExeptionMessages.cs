﻿namespace P04.Wild_Farm.Exeptions
{
    public class ExeptionMessages
    {
        public const string WrongFood = "{0} does not eat {1}!";
        public const string InvalidFoodType = "Invalid food type!";
        public const string InvalidAnimalType = "Invalid animal type!";
    }
}
