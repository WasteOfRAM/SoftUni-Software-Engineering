﻿namespace P04.Wild_Farm.Models.Foods
{
    public class Meat : Food
    {
        public Meat(int quantity) 
            : base(quantity)
        {
        }
    }
}
